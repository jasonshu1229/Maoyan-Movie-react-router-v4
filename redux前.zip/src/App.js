import React from 'react';
import './App.css';
import Tabbar from './Components/Tabbar/index';
class App extends React.Component{

  state = {
    isShow: true
  }

  render() {
    return <div>
      {/* 路由容器 给 根路由 留位置 */}
      {
        this.state.isShow?
        <Tabbar/>
        : null
      }
      { this.props.children}
    </div>
  }
}

export default App;
 