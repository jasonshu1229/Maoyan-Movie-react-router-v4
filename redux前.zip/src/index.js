import ReactDOM from 'react-dom';
// import './index.css';
import router from './Router/index'   //更改项目的入口文件

ReactDOM.render(router, document.getElementById('root'));