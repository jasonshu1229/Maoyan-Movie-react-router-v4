import React, { Component } from 'react';

class Comingsoon extends Component{
  render() {
    return <div>Comingsoon</div>
  }
}

export default Comingsoon