import React, { Component } from 'react';

class Cinema extends Component {
  render() {
    return <div>cinema</div>
  }
}

export default Cinema